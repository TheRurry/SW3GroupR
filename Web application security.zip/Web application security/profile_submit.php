<?php
$conn = mysqli_connect("localhost", "root", "", "simpsons");
if(!$conn){
  die("connection failed: ".mysqli_connect_error());
}
$userid = $_POST['userid'];
$name = $_POST['username'];
$c_pw = $_POST['current_password'];
$n_pw = $_POST['new_password'];

if (is_correct_password($userid, $c_pw)) {
	session_start();
	$sql = "UPDATE students
	SET name='$name', password='$n_pw'
	WHERE id='$userid'";
	$result = mysqli_query($conn, $sql);
	if(!$result){
	  die("Could not update data: ". mmysql_error());
	}
	echo "Updated data successfully\n";
	header("Location: profile.php?userid=".$userid);
}

function is_correct_password($id, $pw) {
	$db = new PDO("mysql:dbname=simpsons", "root", "");
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$rows = $db->query("SELECT password FROM students WHERE id = '$id'");
	foreach ($rows as $row) {
		$correct_password = $row["password"];
		if ($pw == $correct_password) {
			return TRUE;
		}
	}
	return FALSE;
}

?>
